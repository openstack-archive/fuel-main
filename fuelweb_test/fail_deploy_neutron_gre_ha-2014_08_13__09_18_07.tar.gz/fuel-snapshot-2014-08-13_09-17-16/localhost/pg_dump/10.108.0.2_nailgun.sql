--
-- PostgreSQL database dump
--

SET statement_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SET check_function_bodies = false;
SET client_min_messages = warning;

--
-- Name: plpgsql; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS plpgsql WITH SCHEMA pg_catalog;


--
-- Name: EXTENSION plpgsql; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION plpgsql IS 'PL/pgSQL procedural language';


SET search_path = public, pg_catalog;

--
-- Name: bond_mode; Type: TYPE; Schema: public; Owner: nailgun
--

CREATE TYPE bond_mode AS ENUM (
    'active-backup',
    'balance-slb',
    'lacp-balance-tcp'
);


ALTER TYPE public.bond_mode OWNER TO nailgun;

--
-- Name: cluster_grouping; Type: TYPE; Schema: public; Owner: nailgun
--

CREATE TYPE cluster_grouping AS ENUM (
    'roles',
    'hardware',
    'both'
);


ALTER TYPE public.cluster_grouping OWNER TO nailgun;

--
-- Name: cluster_mode; Type: TYPE; Schema: public; Owner: nailgun
--

CREATE TYPE cluster_mode AS ENUM (
    'multinode',
    'ha_full',
    'ha_compact'
);


ALTER TYPE public.cluster_mode OWNER TO nailgun;

--
-- Name: cluster_net_manager; Type: TYPE; Schema: public; Owner: nailgun
--

CREATE TYPE cluster_net_manager AS ENUM (
    'FlatDHCPManager',
    'VlanManager'
);


ALTER TYPE public.cluster_net_manager OWNER TO nailgun;

--
-- Name: cluster_status; Type: TYPE; Schema: public; Owner: nailgun
--

CREATE TYPE cluster_status AS ENUM (
    'new',
    'deployment',
    'stopped',
    'operational',
    'error',
    'remove'
);


ALTER TYPE public.cluster_status OWNER TO nailgun;

--
-- Name: license_type; Type: TYPE; Schema: public; Owner: nailgun
--

CREATE TYPE license_type AS ENUM (
    'rhsm',
    'rhn'
);


ALTER TYPE public.license_type OWNER TO nailgun;

--
-- Name: net_l23_provider; Type: TYPE; Schema: public; Owner: nailgun
--

CREATE TYPE net_l23_provider AS ENUM (
    'ovs'
);


ALTER TYPE public.net_l23_provider OWNER TO nailgun;

--
-- Name: net_provider; Type: TYPE; Schema: public; Owner: nailgun
--

CREATE TYPE net_provider AS ENUM (
    'nova_network',
    'neutron'
);


ALTER TYPE public.net_provider OWNER TO nailgun;

--
-- Name: network_group_name; Type: TYPE; Schema: public; Owner: nailgun
--

CREATE TYPE network_group_name AS ENUM (
    'fuelweb_admin',
    'storage',
    'management',
    'public',
    'fixed',
    'private'
);


ALTER TYPE public.network_group_name OWNER TO nailgun;

--
-- Name: node_error_type; Type: TYPE; Schema: public; Owner: nailgun
--

CREATE TYPE node_error_type AS ENUM (
    'deploy',
    'provision',
    'deletion'
);


ALTER TYPE public.node_error_type OWNER TO nailgun;

--
-- Name: node_status; Type: TYPE; Schema: public; Owner: nailgun
--

CREATE TYPE node_status AS ENUM (
    'ready',
    'discover',
    'provisioning',
    'provisioned',
    'deploying',
    'error'
);


ALTER TYPE public.node_status OWNER TO nailgun;

--
-- Name: notif_status; Type: TYPE; Schema: public; Owner: nailgun
--

CREATE TYPE notif_status AS ENUM (
    'read',
    'unread'
);


ALTER TYPE public.notif_status OWNER TO nailgun;

--
-- Name: notif_topic; Type: TYPE; Schema: public; Owner: nailgun
--

CREATE TYPE notif_topic AS ENUM (
    'discover',
    'done',
    'error',
    'warning'
);


ALTER TYPE public.notif_topic OWNER TO nailgun;

--
-- Name: possible_changes; Type: TYPE; Schema: public; Owner: nailgun
--

CREATE TYPE possible_changes AS ENUM (
    'networks',
    'attributes',
    'disks'
);


ALTER TYPE public.possible_changes OWNER TO nailgun;

--
-- Name: release_state; Type: TYPE; Schema: public; Owner: nailgun
--

CREATE TYPE release_state AS ENUM (
    'not_available',
    'downloading',
    'error',
    'available'
);


ALTER TYPE public.release_state OWNER TO nailgun;

--
-- Name: segmentation_type; Type: TYPE; Schema: public; Owner: nailgun
--

CREATE TYPE segmentation_type AS ENUM (
    'vlan',
    'gre'
);


ALTER TYPE public.segmentation_type OWNER TO nailgun;

--
-- Name: task_name; Type: TYPE; Schema: public; Owner: nailgun
--

CREATE TYPE task_name AS ENUM (
    'super',
    'deploy',
    'deployment',
    'provision',
    'stop_deployment',
    'reset_environment',
    'node_deletion',
    'cluster_deletion',
    'check_before_deployment',
    'check_networks',
    'verify_networks',
    'check_dhcp',
    'verify_network_connectivity',
    'redhat_setup',
    'redhat_check_credentials',
    'redhat_check_licenses',
    'redhat_download_release',
    'redhat_update_cobbler_profile',
    'dump',
    'capacity_log'
);


ALTER TYPE public.task_name OWNER TO nailgun;

--
-- Name: task_status; Type: TYPE; Schema: public; Owner: nailgun
--

CREATE TYPE task_status AS ENUM (
    'ready',
    'running',
    'error'
);


ALTER TYPE public.task_status OWNER TO nailgun;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: alembic_version; Type: TABLE; Schema: public; Owner: nailgun; Tablespace: 
--

CREATE TABLE alembic_version (
    version_num character varying(32) NOT NULL
);


ALTER TABLE public.alembic_version OWNER TO nailgun;

--
-- Name: attributes; Type: TABLE; Schema: public; Owner: nailgun; Tablespace: 
--

CREATE TABLE attributes (
    id integer NOT NULL,
    cluster_id integer,
    editable text,
    generated text
);


ALTER TABLE public.attributes OWNER TO nailgun;

--
-- Name: attributes_id_seq; Type: SEQUENCE; Schema: public; Owner: nailgun
--

CREATE SEQUENCE attributes_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.attributes_id_seq OWNER TO nailgun;

--
-- Name: attributes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: nailgun
--

ALTER SEQUENCE attributes_id_seq OWNED BY attributes.id;


--
-- Name: capacity_log; Type: TABLE; Schema: public; Owner: nailgun; Tablespace: 
--

CREATE TABLE capacity_log (
    id integer NOT NULL,
    report text,
    datetime timestamp without time zone
);


ALTER TABLE public.capacity_log OWNER TO nailgun;

--
-- Name: capacity_log_id_seq; Type: SEQUENCE; Schema: public; Owner: nailgun
--

CREATE SEQUENCE capacity_log_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.capacity_log_id_seq OWNER TO nailgun;

--
-- Name: capacity_log_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: nailgun
--

ALTER SEQUENCE capacity_log_id_seq OWNED BY capacity_log.id;


--
-- Name: cluster_changes; Type: TABLE; Schema: public; Owner: nailgun; Tablespace: 
--

CREATE TABLE cluster_changes (
    id integer NOT NULL,
    cluster_id integer,
    node_id integer,
    name possible_changes NOT NULL
);


ALTER TABLE public.cluster_changes OWNER TO nailgun;

--
-- Name: cluster_changes_id_seq; Type: SEQUENCE; Schema: public; Owner: nailgun
--

CREATE SEQUENCE cluster_changes_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.cluster_changes_id_seq OWNER TO nailgun;

--
-- Name: cluster_changes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: nailgun
--

ALTER SEQUENCE cluster_changes_id_seq OWNED BY cluster_changes.id;


--
-- Name: clusters; Type: TABLE; Schema: public; Owner: nailgun; Tablespace: 
--

CREATE TABLE clusters (
    id integer NOT NULL,
    mode cluster_mode NOT NULL,
    status cluster_status NOT NULL,
    net_provider net_provider NOT NULL,
    grouping cluster_grouping NOT NULL,
    name character varying(50) NOT NULL,
    release_id integer NOT NULL,
    replaced_deployment_info text,
    replaced_provisioning_info text,
    is_customized boolean,
    fuel_version text NOT NULL
);


ALTER TABLE public.clusters OWNER TO nailgun;

--
-- Name: clusters_id_seq; Type: SEQUENCE; Schema: public; Owner: nailgun
--

CREATE SEQUENCE clusters_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.clusters_id_seq OWNER TO nailgun;

--
-- Name: clusters_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: nailgun
--

ALTER SEQUENCE clusters_id_seq OWNED BY clusters.id;


--
-- Name: ip_addr_ranges; Type: TABLE; Schema: public; Owner: nailgun; Tablespace: 
--

CREATE TABLE ip_addr_ranges (
    id integer NOT NULL,
    network_group_id integer,
    first character varying(25) NOT NULL,
    last character varying(25) NOT NULL
);


ALTER TABLE public.ip_addr_ranges OWNER TO nailgun;

--
-- Name: ip_addr_ranges_id_seq; Type: SEQUENCE; Schema: public; Owner: nailgun
--

CREATE SEQUENCE ip_addr_ranges_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.ip_addr_ranges_id_seq OWNER TO nailgun;

--
-- Name: ip_addr_ranges_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: nailgun
--

ALTER SEQUENCE ip_addr_ranges_id_seq OWNED BY ip_addr_ranges.id;


--
-- Name: ip_addrs; Type: TABLE; Schema: public; Owner: nailgun; Tablespace: 
--

CREATE TABLE ip_addrs (
    id integer NOT NULL,
    network integer,
    node integer,
    ip_addr character varying(25) NOT NULL
);


ALTER TABLE public.ip_addrs OWNER TO nailgun;

--
-- Name: ip_addrs_id_seq; Type: SEQUENCE; Schema: public; Owner: nailgun
--

CREATE SEQUENCE ip_addrs_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.ip_addrs_id_seq OWNER TO nailgun;

--
-- Name: ip_addrs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: nailgun
--

ALTER SEQUENCE ip_addrs_id_seq OWNED BY ip_addrs.id;


--
-- Name: net_bond_assignments; Type: TABLE; Schema: public; Owner: nailgun; Tablespace: 
--

CREATE TABLE net_bond_assignments (
    id integer NOT NULL,
    network_id integer NOT NULL,
    bond_id integer NOT NULL
);


ALTER TABLE public.net_bond_assignments OWNER TO nailgun;

--
-- Name: net_bond_assignments_id_seq; Type: SEQUENCE; Schema: public; Owner: nailgun
--

CREATE SEQUENCE net_bond_assignments_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.net_bond_assignments_id_seq OWNER TO nailgun;

--
-- Name: net_bond_assignments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: nailgun
--

ALTER SEQUENCE net_bond_assignments_id_seq OWNED BY net_bond_assignments.id;


--
-- Name: net_nic_assignments; Type: TABLE; Schema: public; Owner: nailgun; Tablespace: 
--

CREATE TABLE net_nic_assignments (
    id integer NOT NULL,
    network_id integer NOT NULL,
    interface_id integer NOT NULL
);


ALTER TABLE public.net_nic_assignments OWNER TO nailgun;

--
-- Name: net_nic_assignments_id_seq; Type: SEQUENCE; Schema: public; Owner: nailgun
--

CREATE SEQUENCE net_nic_assignments_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.net_nic_assignments_id_seq OWNER TO nailgun;

--
-- Name: net_nic_assignments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: nailgun
--

ALTER SEQUENCE net_nic_assignments_id_seq OWNED BY net_nic_assignments.id;


--
-- Name: network_groups; Type: TABLE; Schema: public; Owner: nailgun; Tablespace: 
--

CREATE TABLE network_groups (
    id integer NOT NULL,
    name network_group_name NOT NULL,
    release integer,
    cluster_id integer,
    vlan_start integer,
    cidr character varying(25),
    gateway character varying(25),
    meta text
);


ALTER TABLE public.network_groups OWNER TO nailgun;

--
-- Name: network_groups_id_seq; Type: SEQUENCE; Schema: public; Owner: nailgun
--

CREATE SEQUENCE network_groups_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.network_groups_id_seq OWNER TO nailgun;

--
-- Name: network_groups_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: nailgun
--

ALTER SEQUENCE network_groups_id_seq OWNED BY network_groups.id;


--
-- Name: networking_configs; Type: TABLE; Schema: public; Owner: nailgun; Tablespace: 
--

CREATE TABLE networking_configs (
    id integer NOT NULL,
    discriminator character varying(50),
    cluster_id integer,
    dns_nameservers text,
    floating_ranges text
);


ALTER TABLE public.networking_configs OWNER TO nailgun;

--
-- Name: networking_configs_id_seq; Type: SEQUENCE; Schema: public; Owner: nailgun
--

CREATE SEQUENCE networking_configs_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.networking_configs_id_seq OWNER TO nailgun;

--
-- Name: networking_configs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: nailgun
--

ALTER SEQUENCE networking_configs_id_seq OWNED BY networking_configs.id;


--
-- Name: neutron_config; Type: TABLE; Schema: public; Owner: nailgun; Tablespace: 
--

CREATE TABLE neutron_config (
    id integer NOT NULL,
    vlan_range text,
    gre_id_range text,
    base_mac character varying NOT NULL,
    internal_cidr character varying(25),
    internal_gateway character varying(25),
    segmentation_type segmentation_type NOT NULL,
    net_l23_provider net_l23_provider NOT NULL
);


ALTER TABLE public.neutron_config OWNER TO nailgun;

--
-- Name: node_attributes; Type: TABLE; Schema: public; Owner: nailgun; Tablespace: 
--

CREATE TABLE node_attributes (
    id integer NOT NULL,
    node_id integer,
    volumes text,
    interfaces text
);


ALTER TABLE public.node_attributes OWNER TO nailgun;

--
-- Name: node_attributes_id_seq; Type: SEQUENCE; Schema: public; Owner: nailgun
--

CREATE SEQUENCE node_attributes_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.node_attributes_id_seq OWNER TO nailgun;

--
-- Name: node_attributes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: nailgun
--

ALTER SEQUENCE node_attributes_id_seq OWNED BY node_attributes.id;


--
-- Name: node_bond_interfaces; Type: TABLE; Schema: public; Owner: nailgun; Tablespace: 
--

CREATE TABLE node_bond_interfaces (
    id integer NOT NULL,
    node_id integer NOT NULL,
    name character varying(32) NOT NULL,
    mac character varying,
    state character varying(25),
    flags text,
    mode bond_mode NOT NULL
);


ALTER TABLE public.node_bond_interfaces OWNER TO nailgun;

--
-- Name: node_bond_interfaces_id_seq; Type: SEQUENCE; Schema: public; Owner: nailgun
--

CREATE SEQUENCE node_bond_interfaces_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.node_bond_interfaces_id_seq OWNER TO nailgun;

--
-- Name: node_bond_interfaces_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: nailgun
--

ALTER SEQUENCE node_bond_interfaces_id_seq OWNED BY node_bond_interfaces.id;


--
-- Name: node_nic_interfaces; Type: TABLE; Schema: public; Owner: nailgun; Tablespace: 
--

CREATE TABLE node_nic_interfaces (
    id integer NOT NULL,
    node_id integer NOT NULL,
    name character varying(128) NOT NULL,
    mac character varying NOT NULL,
    max_speed integer,
    current_speed integer,
    ip_addr character varying(25),
    netmask character varying(25),
    state character varying(25),
    parent_id integer
);


ALTER TABLE public.node_nic_interfaces OWNER TO nailgun;

--
-- Name: node_nic_interfaces_id_seq; Type: SEQUENCE; Schema: public; Owner: nailgun
--

CREATE SEQUENCE node_nic_interfaces_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.node_nic_interfaces_id_seq OWNER TO nailgun;

--
-- Name: node_nic_interfaces_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: nailgun
--

ALTER SEQUENCE node_nic_interfaces_id_seq OWNED BY node_nic_interfaces.id;


--
-- Name: node_roles; Type: TABLE; Schema: public; Owner: nailgun; Tablespace: 
--

CREATE TABLE node_roles (
    id integer NOT NULL,
    role integer,
    node integer
);


ALTER TABLE public.node_roles OWNER TO nailgun;

--
-- Name: node_roles_id_seq; Type: SEQUENCE; Schema: public; Owner: nailgun
--

CREATE SEQUENCE node_roles_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.node_roles_id_seq OWNER TO nailgun;

--
-- Name: node_roles_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: nailgun
--

ALTER SEQUENCE node_roles_id_seq OWNED BY node_roles.id;


--
-- Name: nodes; Type: TABLE; Schema: public; Owner: nailgun; Tablespace: 
--

CREATE TABLE nodes (
    id integer NOT NULL,
    uuid character varying(36) NOT NULL,
    cluster_id integer,
    name character varying(100),
    status node_status NOT NULL,
    meta text,
    mac character varying NOT NULL,
    ip character varying(15),
    fqdn character varying(255),
    manufacturer character varying(50),
    platform_name character varying(150),
    kernel_params text,
    progress integer,
    os_platform character varying(150),
    pending_addition boolean,
    pending_deletion boolean,
    error_type node_error_type,
    error_msg character varying(255),
    "timestamp" timestamp without time zone NOT NULL,
    online boolean,
    agent_checksum character varying(40)
);


ALTER TABLE public.nodes OWNER TO nailgun;

--
-- Name: nodes_id_seq; Type: SEQUENCE; Schema: public; Owner: nailgun
--

CREATE SEQUENCE nodes_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.nodes_id_seq OWNER TO nailgun;

--
-- Name: nodes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: nailgun
--

ALTER SEQUENCE nodes_id_seq OWNED BY nodes.id;


--
-- Name: notifications; Type: TABLE; Schema: public; Owner: nailgun; Tablespace: 
--

CREATE TABLE notifications (
    id integer NOT NULL,
    cluster_id integer,
    node_id integer,
    task_id integer,
    topic notif_topic NOT NULL,
    message text,
    status notif_status NOT NULL,
    datetime timestamp without time zone NOT NULL
);


ALTER TABLE public.notifications OWNER TO nailgun;

--
-- Name: notifications_id_seq; Type: SEQUENCE; Schema: public; Owner: nailgun
--

CREATE SEQUENCE notifications_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.notifications_id_seq OWNER TO nailgun;

--
-- Name: notifications_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: nailgun
--

ALTER SEQUENCE notifications_id_seq OWNED BY notifications.id;


--
-- Name: nova_network_config; Type: TABLE; Schema: public; Owner: nailgun; Tablespace: 
--

CREATE TABLE nova_network_config (
    id integer NOT NULL,
    fixed_networks_cidr character varying(25),
    fixed_networks_vlan_start integer,
    fixed_network_size integer NOT NULL,
    fixed_networks_amount integer NOT NULL,
    net_manager cluster_net_manager NOT NULL
);


ALTER TABLE public.nova_network_config OWNER TO nailgun;

--
-- Name: pending_node_roles; Type: TABLE; Schema: public; Owner: nailgun; Tablespace: 
--

CREATE TABLE pending_node_roles (
    id integer NOT NULL,
    role integer,
    node integer
);


ALTER TABLE public.pending_node_roles OWNER TO nailgun;

--
-- Name: pending_node_roles_id_seq; Type: SEQUENCE; Schema: public; Owner: nailgun
--

CREATE SEQUENCE pending_node_roles_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.pending_node_roles_id_seq OWNER TO nailgun;

--
-- Name: pending_node_roles_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: nailgun
--

ALTER SEQUENCE pending_node_roles_id_seq OWNED BY pending_node_roles.id;


--
-- Name: red_hat_accounts; Type: TABLE; Schema: public; Owner: nailgun; Tablespace: 
--

CREATE TABLE red_hat_accounts (
    id integer NOT NULL,
    username character varying(100) NOT NULL,
    password character varying(100) NOT NULL,
    license_type license_type NOT NULL,
    satellite character varying(250),
    activation_key character varying(300)
);


ALTER TABLE public.red_hat_accounts OWNER TO nailgun;

--
-- Name: red_hat_accounts_id_seq; Type: SEQUENCE; Schema: public; Owner: nailgun
--

CREATE SEQUENCE red_hat_accounts_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.red_hat_accounts_id_seq OWNER TO nailgun;

--
-- Name: red_hat_accounts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: nailgun
--

ALTER SEQUENCE red_hat_accounts_id_seq OWNED BY red_hat_accounts.id;


--
-- Name: release_orchestrator_data; Type: TABLE; Schema: public; Owner: nailgun; Tablespace: 
--

CREATE TABLE release_orchestrator_data (
    id integer NOT NULL,
    release_id integer NOT NULL,
    repo_metadata text NOT NULL,
    puppet_manifests_source text NOT NULL,
    puppet_modules_source text NOT NULL
);


ALTER TABLE public.release_orchestrator_data OWNER TO nailgun;

--
-- Name: release_orchestrator_data_id_seq; Type: SEQUENCE; Schema: public; Owner: nailgun
--

CREATE SEQUENCE release_orchestrator_data_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.release_orchestrator_data_id_seq OWNER TO nailgun;

--
-- Name: release_orchestrator_data_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: nailgun
--

ALTER SEQUENCE release_orchestrator_data_id_seq OWNED BY release_orchestrator_data.id;


--
-- Name: releases; Type: TABLE; Schema: public; Owner: nailgun; Tablespace: 
--

CREATE TABLE releases (
    id integer NOT NULL,
    name character varying(100) NOT NULL,
    version character varying(30) NOT NULL,
    description character varying,
    operating_system character varying(50) NOT NULL,
    state release_state NOT NULL,
    networks_metadata text,
    attributes_metadata text,
    volumes_metadata text,
    modes_metadata text,
    roles_metadata text
);


ALTER TABLE public.releases OWNER TO nailgun;

--
-- Name: releases_id_seq; Type: SEQUENCE; Schema: public; Owner: nailgun
--

CREATE SEQUENCE releases_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.releases_id_seq OWNER TO nailgun;

--
-- Name: releases_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: nailgun
--

ALTER SEQUENCE releases_id_seq OWNED BY releases.id;


--
-- Name: roles; Type: TABLE; Schema: public; Owner: nailgun; Tablespace: 
--

CREATE TABLE roles (
    id integer NOT NULL,
    release_id integer NOT NULL,
    name character varying(50) NOT NULL
);


ALTER TABLE public.roles OWNER TO nailgun;

--
-- Name: roles_id_seq; Type: SEQUENCE; Schema: public; Owner: nailgun
--

CREATE SEQUENCE roles_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.roles_id_seq OWNER TO nailgun;

--
-- Name: roles_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: nailgun
--

ALTER SEQUENCE roles_id_seq OWNED BY roles.id;


--
-- Name: tasks; Type: TABLE; Schema: public; Owner: nailgun; Tablespace: 
--

CREATE TABLE tasks (
    id integer NOT NULL,
    cluster_id integer,
    uuid character varying(36) NOT NULL,
    name task_name NOT NULL,
    message text,
    status task_status NOT NULL,
    progress integer,
    cache text,
    result text,
    parent_id integer,
    weight double precision
);


ALTER TABLE public.tasks OWNER TO nailgun;

--
-- Name: tasks_id_seq; Type: SEQUENCE; Schema: public; Owner: nailgun
--

CREATE SEQUENCE tasks_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.tasks_id_seq OWNER TO nailgun;

--
-- Name: tasks_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: nailgun
--

ALTER SEQUENCE tasks_id_seq OWNED BY tasks.id;


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: nailgun
--

ALTER TABLE ONLY attributes ALTER COLUMN id SET DEFAULT nextval('attributes_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: nailgun
--

ALTER TABLE ONLY capacity_log ALTER COLUMN id SET DEFAULT nextval('capacity_log_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: nailgun
--

ALTER TABLE ONLY cluster_changes ALTER COLUMN id SET DEFAULT nextval('cluster_changes_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: nailgun
--

ALTER TABLE ONLY clusters ALTER COLUMN id SET DEFAULT nextval('clusters_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: nailgun
--

ALTER TABLE ONLY ip_addr_ranges ALTER COLUMN id SET DEFAULT nextval('ip_addr_ranges_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: nailgun
--

ALTER TABLE ONLY ip_addrs ALTER COLUMN id SET DEFAULT nextval('ip_addrs_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: nailgun
--

ALTER TABLE ONLY net_bond_assignments ALTER COLUMN id SET DEFAULT nextval('net_bond_assignments_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: nailgun
--

ALTER TABLE ONLY net_nic_assignments ALTER COLUMN id SET DEFAULT nextval('net_nic_assignments_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: nailgun
--

ALTER TABLE ONLY network_groups ALTER COLUMN id SET DEFAULT nextval('network_groups_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: nailgun
--

ALTER TABLE ONLY networking_configs ALTER COLUMN id SET DEFAULT nextval('networking_configs_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: nailgun
--

ALTER TABLE ONLY node_attributes ALTER COLUMN id SET DEFAULT nextval('node_attributes_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: nailgun
--

ALTER TABLE ONLY node_bond_interfaces ALTER COLUMN id SET DEFAULT nextval('node_bond_interfaces_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: nailgun
--

ALTER TABLE ONLY node_nic_interfaces ALTER COLUMN id SET DEFAULT nextval('node_nic_interfaces_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: nailgun
--

ALTER TABLE ONLY node_roles ALTER COLUMN id SET DEFAULT nextval('node_roles_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: nailgun
--

ALTER TABLE ONLY nodes ALTER COLUMN id SET DEFAULT nextval('nodes_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: nailgun
--

ALTER TABLE ONLY notifications ALTER COLUMN id SET DEFAULT nextval('notifications_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: nailgun
--

ALTER TABLE ONLY pending_node_roles ALTER COLUMN id SET DEFAULT nextval('pending_node_roles_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: nailgun
--

ALTER TABLE ONLY red_hat_accounts ALTER COLUMN id SET DEFAULT nextval('red_hat_accounts_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: nailgun
--

ALTER TABLE ONLY release_orchestrator_data ALTER COLUMN id SET DEFAULT nextval('release_orchestrator_data_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: nailgun
--

ALTER TABLE ONLY releases ALTER COLUMN id SET DEFAULT nextval('releases_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: nailgun
--

ALTER TABLE ONLY roles ALTER COLUMN id SET DEFAULT nextval('roles_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: nailgun
--

ALTER TABLE ONLY tasks ALTER COLUMN id SET DEFAULT nextval('tasks_id_seq'::regclass);


--
-- Data for Name: alembic_version; Type: TABLE DATA; Schema: public; Owner: nailgun
--

COPY alembic_version (version_num) FROM stdin;
1a1504d469f8
\.


--
-- Data for Name: attributes; Type: TABLE DATA; Schema: public; Owner: nailgun
--

COPY attributes (id, cluster_id, editable, generated) FROM stdin;
\.


--
-- Name: attributes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: nailgun
--

SELECT pg_catalog.setval('attributes_id_seq', 1, false);


--
-- Data for Name: capacity_log; Type: TABLE DATA; Schema: public; Owner: nailgun
--

COPY capacity_log (id, report, datetime) FROM stdin;
\.


--
-- Name: capacity_log_id_seq; Type: SEQUENCE SET; Schema: public; Owner: nailgun
--

SELECT pg_catalog.setval('capacity_log_id_seq', 1, false);


--
-- Data for Name: cluster_changes; Type: TABLE DATA; Schema: public; Owner: nailgun
--

COPY cluster_changes (id, cluster_id, node_id, name) FROM stdin;
\.


--
-- Name: cluster_changes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: nailgun
--

SELECT pg_catalog.setval('cluster_changes_id_seq', 1, false);


--
-- Data for Name: clusters; Type: TABLE DATA; Schema: public; Owner: nailgun
--

COPY clusters (id, mode, status, net_provider, grouping, name, release_id, replaced_deployment_info, replaced_provisioning_info, is_customized, fuel_version) FROM stdin;
\.


--
-- Name: clusters_id_seq; Type: SEQUENCE SET; Schema: public; Owner: nailgun
--

SELECT pg_catalog.setval('clusters_id_seq', 1, false);


--
-- Data for Name: ip_addr_ranges; Type: TABLE DATA; Schema: public; Owner: nailgun
--

COPY ip_addr_ranges (id, network_group_id, first, last) FROM stdin;
1	1	10.108.0.3	10.108.0.127
\.


--
-- Name: ip_addr_ranges_id_seq; Type: SEQUENCE SET; Schema: public; Owner: nailgun
--

SELECT pg_catalog.setval('ip_addr_ranges_id_seq', 1, true);


--
-- Data for Name: ip_addrs; Type: TABLE DATA; Schema: public; Owner: nailgun
--

COPY ip_addrs (id, network, node, ip_addr) FROM stdin;
1	1	\N	10.108.0.2
\.


--
-- Name: ip_addrs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: nailgun
--

SELECT pg_catalog.setval('ip_addrs_id_seq', 1, true);


--
-- Data for Name: net_bond_assignments; Type: TABLE DATA; Schema: public; Owner: nailgun
--

COPY net_bond_assignments (id, network_id, bond_id) FROM stdin;
\.


--
-- Name: net_bond_assignments_id_seq; Type: SEQUENCE SET; Schema: public; Owner: nailgun
--

SELECT pg_catalog.setval('net_bond_assignments_id_seq', 1, false);


--
-- Data for Name: net_nic_assignments; Type: TABLE DATA; Schema: public; Owner: nailgun
--

COPY net_nic_assignments (id, network_id, interface_id) FROM stdin;
\.


--
-- Name: net_nic_assignments_id_seq; Type: SEQUENCE SET; Schema: public; Owner: nailgun
--

SELECT pg_catalog.setval('net_nic_assignments_id_seq', 1, false);


--
-- Data for Name: network_groups; Type: TABLE DATA; Schema: public; Owner: nailgun
--

COPY network_groups (id, name, release, cluster_id, vlan_start, cidr, gateway, meta) FROM stdin;
1	fuelweb_admin	\N	\N	\N	10.108.0.0/24	\N	{"notation": "cidr", "render_type": null, "assign_vip": false, "configurable": false, "unmovable": true, "use_gateway": false, "render_addr_mask": null, "map_priority": 0}
\.


--
-- Name: network_groups_id_seq; Type: SEQUENCE SET; Schema: public; Owner: nailgun
--

SELECT pg_catalog.setval('network_groups_id_seq', 1, true);


--
-- Data for Name: networking_configs; Type: TABLE DATA; Schema: public; Owner: nailgun
--

COPY networking_configs (id, discriminator, cluster_id, dns_nameservers, floating_ranges) FROM stdin;
\.


--
-- Name: networking_configs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: nailgun
--

SELECT pg_catalog.setval('networking_configs_id_seq', 1, false);


--
-- Data for Name: neutron_config; Type: TABLE DATA; Schema: public; Owner: nailgun
--

COPY neutron_config (id, vlan_range, gre_id_range, base_mac, internal_cidr, internal_gateway, segmentation_type, net_l23_provider) FROM stdin;
\.


--
-- Data for Name: node_attributes; Type: TABLE DATA; Schema: public; Owner: nailgun
--

COPY node_attributes (id, node_id, volumes, interfaces) FROM stdin;
\.


--
-- Name: node_attributes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: nailgun
--

SELECT pg_catalog.setval('node_attributes_id_seq', 1, false);


--
-- Data for Name: node_bond_interfaces; Type: TABLE DATA; Schema: public; Owner: nailgun
--

COPY node_bond_interfaces (id, node_id, name, mac, state, flags, mode) FROM stdin;
\.


--
-- Name: node_bond_interfaces_id_seq; Type: SEQUENCE SET; Schema: public; Owner: nailgun
--

SELECT pg_catalog.setval('node_bond_interfaces_id_seq', 1, false);


--
-- Data for Name: node_nic_interfaces; Type: TABLE DATA; Schema: public; Owner: nailgun
--

COPY node_nic_interfaces (id, node_id, name, mac, max_speed, current_speed, ip_addr, netmask, state, parent_id) FROM stdin;
\.


--
-- Name: node_nic_interfaces_id_seq; Type: SEQUENCE SET; Schema: public; Owner: nailgun
--

SELECT pg_catalog.setval('node_nic_interfaces_id_seq', 1, false);


--
-- Data for Name: node_roles; Type: TABLE DATA; Schema: public; Owner: nailgun
--

COPY node_roles (id, role, node) FROM stdin;
\.


--
-- Name: node_roles_id_seq; Type: SEQUENCE SET; Schema: public; Owner: nailgun
--

SELECT pg_catalog.setval('node_roles_id_seq', 1, false);


--
-- Data for Name: nodes; Type: TABLE DATA; Schema: public; Owner: nailgun
--

COPY nodes (id, uuid, cluster_id, name, status, meta, mac, ip, fqdn, manufacturer, platform_name, kernel_params, progress, os_platform, pending_addition, pending_deletion, error_type, error_msg, "timestamp", online, agent_checksum) FROM stdin;
\.


--
-- Name: nodes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: nailgun
--

SELECT pg_catalog.setval('nodes_id_seq', 1, false);


--
-- Data for Name: notifications; Type: TABLE DATA; Schema: public; Owner: nailgun
--

COPY notifications (id, cluster_id, node_id, task_id, topic, message, status, datetime) FROM stdin;
1	\N	\N	\N	done	Master node installation has been completed successfully. Now you can boot new nodes over PXE, they will be discovered and become available for installing OpenStack on them	unread	2014-08-13 08:14:47.976547
\.


--
-- Name: notifications_id_seq; Type: SEQUENCE SET; Schema: public; Owner: nailgun
--

SELECT pg_catalog.setval('notifications_id_seq', 1, true);


--
-- Data for Name: nova_network_config; Type: TABLE DATA; Schema: public; Owner: nailgun
--

COPY nova_network_config (id, fixed_networks_cidr, fixed_networks_vlan_start, fixed_network_size, fixed_networks_amount, net_manager) FROM stdin;
\.


--
-- Data for Name: pending_node_roles; Type: TABLE DATA; Schema: public; Owner: nailgun
--

COPY pending_node_roles (id, role, node) FROM stdin;
\.


--
-- Name: pending_node_roles_id_seq; Type: SEQUENCE SET; Schema: public; Owner: nailgun
--

SELECT pg_catalog.setval('pending_node_roles_id_seq', 1, false);


--
-- Data for Name: red_hat_accounts; Type: TABLE DATA; Schema: public; Owner: nailgun
--

COPY red_hat_accounts (id, username, password, license_type, satellite, activation_key) FROM stdin;
\.


--
-- Name: red_hat_accounts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: nailgun
--

SELECT pg_catalog.setval('red_hat_accounts_id_seq', 1, false);


--
-- Data for Name: release_orchestrator_data; Type: TABLE DATA; Schema: public; Owner: nailgun
--

COPY release_orchestrator_data (id, release_id, repo_metadata, puppet_manifests_source, puppet_modules_source) FROM stdin;
\.


--
-- Name: release_orchestrator_data_id_seq; Type: SEQUENCE SET; Schema: public; Owner: nailgun
--

SELECT pg_catalog.setval('release_orchestrator_data_id_seq', 1, false);


--
-- Data for Name: releases; Type: TABLE DATA; Schema: public; Owner: nailgun
--

COPY releases (id, name, version, description, operating_system, state, networks_metadata, attributes_metadata, volumes_metadata, modes_metadata, roles_metadata) FROM stdin;
1	Icehouse on CentOS 6.5	2014.1.1-5.0.1	This option will install the OpenStack Icehouse packages using a CentOS based operating system. With high availability features built in, you are getting a robust, enterprise-grade OpenStack deployment.	CentOS	available	{"nova_network": {"config": {"floating_ranges": [["172.16.0.128", "172.16.0.254"]], "net_manager": "FlatDHCPManager", "fixed_networks_vlan_start": 103, "fixed_networks_amount": 1, "fixed_network_size": 256, "fixed_networks_cidr": "10.0.0.0/16"}, "networks": [{"name": "public", "notation": "ip_ranges", "render_type": null, "assign_vip": true, "map_priority": 1, "use_gateway": true, "vlan_start": null, "render_addr_mask": "public", "cidr": "172.16.0.0/24", "configurable": true, "gateway": "172.16.0.1", "ip_range": ["172.16.0.2", "172.16.0.127"]}, {"name": "management", "notation": "cidr", "render_type": "cidr", "assign_vip": true, "map_priority": 2, "use_gateway": false, "vlan_start": 101, "render_addr_mask": "internal", "cidr": "192.168.0.0/24", "configurable": true}, {"name": "storage", "notation": "cidr", "render_type": "cidr", "assign_vip": false, "map_priority": 2, "use_gateway": false, "vlan_start": 102, "render_addr_mask": "storage", "cidr": "192.168.1.0/24", "configurable": true}, {"ext_net_data": ["fixed_networks_vlan_start", "fixed_networks_amount"], "name": "fixed", "notation": null, "render_type": null, "assign_vip": false, "map_priority": 2, "use_gateway": false, "vlan_start": null, "render_addr_mask": null, "configurable": false}]}, "neutron": {"config": {"parameters": {"metadata": {"metadata_proxy_shared_secret": ""}, "keystone": {"admin_user": null, "admin_password": ""}, "amqp": {"username": null, "passwd": "", "hosts": "hostname1:5672, hostname2:5672", "provider": "rabbitmq"}, "database": {"username": null, "passwd": "", "database": null, "port": "3306", "provider": "mysql"}}, "internal_cidr": "192.168.111.0/24", "internal_gateway": "192.168.111.1", "floating_ranges": [["172.16.0.130", "172.16.0.254"]], "base_mac": "fa:16:3e:00:00:00", "gre_id_range": [2, 65535], "vlan_range": [1000, 1030]}, "networks": [{"name": "public", "notation": "ip_ranges", "render_type": null, "map_priority": 1, "assign_vip": true, "floating_range_var": "floating_ranges", "use_gateway": true, "vlan_start": null, "render_addr_mask": "public", "cidr": "172.16.0.0/24", "configurable": true, "ip_range": ["172.16.0.2", "172.16.0.126"]}, {"name": "management", "notation": "cidr", "render_type": "cidr", "map_priority": 2, "assign_vip": true, "use_gateway": false, "vlan_start": 101, "render_addr_mask": "internal", "cidr": "192.168.0.0/24", "configurable": true}, {"name": "storage", "notation": "cidr", "render_type": "cidr", "map_priority": 2, "assign_vip": false, "use_gateway": false, "vlan_start": 102, "render_addr_mask": "storage", "cidr": "192.168.1.0/24", "configurable": true}, {"name": "private", "notation": null, "render_type": null, "map_priority": 2, "assign_vip": false, "use_gateway": false, "vlan_start": null, "render_addr_mask": null, "neutron_vlan_range": true, "configurable": false, "seg_type": "vlan"}]}}	{"generated": {"quantum_settings": {"metadata": {"metadata_proxy_shared_secret": {"generator": "password"}}, "keystone": {"admin_password": {"generator": "password"}}, "database": {"passwd": {"generator": "password"}}}, "base_syslog": {"syslog_port": {"generator": "identical", "generator_arg": "514"}, "syslog_server": {"generator": "ip", "generator_arg": "admin"}}, "ceilometer": {"db_password": {"generator": "password"}, "user_password": {"generator": "password"}, "metering_secret": {"generator": "password"}}, "murano": {"db_password": {"generator": "password"}, "user_password": {"generator": "password"}, "rabbit_password": {"generator": "password"}}, "nova": {"db_password": {"generator": "password"}, "user_password": {"generator": "password"}, "state_path": "/var/lib/nova"}, "heat": {"db_password": {"generator": "password"}, "user_password": {"generator": "password"}, "rabbit_password": {"generator": "password"}}, "sahara": {"db_password": {"generator": "password"}, "user_password": {"generator": "password"}}, "rabbit": {"password": {"generator": "password"}}, "mysql": {"root_password": {"generator": "password"}}, "keystone": {"db_password": {"generator": "password"}, "admin_token": {"generator": "password"}}, "cobbler": {"profile": {"generator": "identical", "generator_arg": "centos-x86_64"}}, "cinder": {"db_password": {"generator": "password"}, "user_password": {"generator": "password"}}, "swift": {"user_password": {"generator": "password"}}, "glance": {"db_password": {"generator": "password"}, "user_password": {"generator": "password"}}}, "editable": {"additional_components": {"murano": {"description": "If selected, Murano component will be installed", "weight": 20, "value": false, "label": "Install Murano", "depends": [{"cluster:net_provider": "neutron"}], "type": "checkbox"}, "ceilometer": {"weight": 40, "type": "checkbox", "description": "If selected, Ceilometer component will be installed", "value": false, "label": "Install Ceilometer"}, "sahara": {"weight": 10, "type": "checkbox", "description": "If selected, Sahara component will be installed", "value": false, "label": "Install Sahara"}, "heat": {"weight": 30, "type": "hidden", "description": "", "value": true, "label": ""}, "metadata": {"weight": 20, "label": "Additional Components"}}, "kernel_params": {"kernel": {"weight": 45, "type": "text", "description": "Default kernel parameters", "value": "console=ttyS0,9600 console=tty0 biosdevname=0 crashkernel=none rootdelay=90 nomodeset", "label": "Initial parameters"}, "metadata": {"weight": 40, "label": "Kernel parameters"}}, "storage": {"volumes_ceph": {"description": "Configures Cinder to store volumes in Ceph RBD images.", "weight": 20, "value": false, "label": "Ceph RBD for volumes (Cinder)", "conflicts": [{"settings:common.libvirt_type.value": "vcenter"}, {"settings:storage.volumes_lvm.value": true}], "type": "checkbox"}, "objects_ceph": {"description": "Configures RadosGW front end for Ceph RBD. This exposes S3 and Swift API Interfaces. If enabled, this option will prevent Swift from installing.", "weight": 40, "value": false, "label": "Ceph RadosGW for objects (Swift API)", "depends": [{"settings:storage.images_ceph.value": true}], "conflicts": [{"settings:common.libvirt_type.value": "vcenter"}], "type": "checkbox"}, "ephemeral_ceph": {"description": "Configures Nova to store ephemeral volumes in RBD. This works best if Ceph is enabled for volumes and images, too. Enables live migration of all types of Ceph backed VMs (without this option, live migration will only work with VMs launched from Cinder volumes).", "weight": 35, "value": false, "label": "Ceph RBD for ephemeral volumes (Nova)", "conflicts": [{"settings:common.libvirt_type.value": "vcenter"}], "type": "checkbox"}, "volumes_lvm": {"description": "Requires at least one Storage - Cinder LVM node.", "weight": 10, "value": true, "label": "Cinder LVM over iSCSI for volumes", "conflicts": [{"settings:storage.volumes_ceph.value": true}], "type": "checkbox"}, "osd_pool_size": {"description": "Configures the default number of object replicas in Ceph. This number must be equal to or lower than the number of deployed 'Storage - Ceph OSD' nodes.", "weight": 70, "value": "2", "label": "Ceph object replication factor", "conflicts": [{"settings:common.libvirt_type.value": "vcenter"}], "type": "text"}, "images_ceph": {"description": "Configures Glance to use the Ceph RBD backend to store images. If enabled, this option will prevent Swift from installing.", "weight": 30, "value": false, "label": "Ceph RBD for images (Glance)", "conflicts": [{"settings:common.libvirt_type.value": "vcenter"}], "type": "checkbox"}, "metadata": {"weight": 60, "label": "Storage"}}, "access": {"user": {"regex": {"source": "^(?!services$)(?!nova$)(?!glance$)(?!keystone$)(?!neutron$)(?!cinder$)(?!swift$)(?!ceph$)(?![Gg]uest$).*", "error": "Invalid username"}, "description": "Username for Administrator", "weight": 10, "value": "admin", "label": "username", "type": "text"}, "password": {"weight": 20, "type": "password", "description": "Password for Administrator", "value": "admin", "label": "password"}, "email": {"weight": 40, "type": "text", "description": "Email address for Administrator", "value": "admin@example.org", "label": "email"}, "tenant": {"regex": {"source": "^(?!services$)(?!nova$)(?!glance$)(?!keystone$)(?!neutron$)(?!cinder$)(?!swift$)(?!ceph$)(?![Gg]uest$).*", "error": "Invalid tenant name"}, "description": "Tenant (project) name for Administrator", "weight": 30, "value": "admin", "label": "tenant", "type": "text"}, "metadata": {"weight": 10, "label": "Access"}}, "syslog": {"syslog_port": {"weight": 20, "type": "text", "description": "Remote syslog port", "value": "514", "label": "Port"}, "syslog_transport": {"type": "radio", "values": [{"data": "udp", "description": "", "label": "UDP"}, {"data": "tcp", "description": "", "label": "TCP"}], "weight": 30, "value": "tcp", "label": "Syslog transport protocol"}, "syslog_server": {"weight": 10, "type": "text", "description": "Remote syslog hostname", "value": "", "label": "Hostname"}, "metadata": {"weight": 50, "label": "Syslog"}}, "common": {"auto_assign_floating_ip": {"description": "If selected, OpenStack will automatically assign a floating IP to a new instance", "weight": 40, "value": false, "label": "Auto assign floating IP", "conflicts": [{"cluster:net_provider": "neutron"}], "type": "checkbox"}, "use_cow_images": {"weight": 50, "type": "checkbox", "description": "For most cases you will want qcow format. If it's disabled, raw image format will be used to run VMs. OpenStack with raw format currently does not support snapshotting.", "value": true, "label": "Use qcow format for images"}, "auth_key": {"weight": 70, "type": "text", "description": "Public key(s) to include in authorized_keys on deployed nodes", "value": "", "label": "Public Key"}, "compute_scheduler_driver": {"type": "radio", "values": [{"data": "nova.scheduler.filter_scheduler.FilterScheduler", "description": "Currently the most advanced OpenStack scheduler. See the OpenStack documentation for details.", "label": "Filter scheduler"}, {"data": "nova.scheduler.simple.SimpleScheduler", "description": "This is 'naive' scheduler which tries to find the least loaded host", "label": "Simple scheduler"}], "weight": 40, "value": "nova.scheduler.filter_scheduler.FilterScheduler", "label": "Scheduler driver"}, "libvirt_type": {"type": "radio", "values": [{"data": "kvm", "description": "Choose this type of hypervisor if you run OpenStack on hardware", "label": "KVM"}, {"data": "qemu", "description": "Choose this type of hypervisor if you run OpenStack on virtual hosts.", "label": "QEMU"}, {"conflicts": [{"cluster:net_provider": "neutron"}], "data": "vcenter", "description": "Choose this type of hypervisor if you run OpenStack in a vCenter environment.", "label": "vCenter"}], "weight": 30, "value": "qemu", "label": "Hypervisor type"}, "start_guests_on_host_boot": {"weight": 60, "type": "checkbox", "description": "Whether to (re-)start guests when the host reboots. If enabled, this option causes guests assigned to the host to be unconditionally restarted when nova-compute starts. If the guest is found to be stopped, it starts. If it is found to be running, it reboots.", "value": true, "label": "Start guests on host boot"}, "debug": {"weight": 20, "type": "checkbox", "description": "Debug logging mode provides more information, but requires more disk space.", "value": false, "label": "OpenStack debug logging"}, "nova_quota": {"weight": 25, "type": "checkbox", "description": "Quotas are used to limit CPU and memory usage for tenants. Enabling quotas will increase load on the Nova database.", "value": false, "label": "Nova quotas"}, "metadata": {"weight": 30, "label": "Common"}}, "vlan_splinters": {"vswitch": {"values": [{"data": "soft", "description": "Configure OVS to use VLAN splinters workaround with soft trunk detection. This may resolve issues that might be encountered when using VLAN tags with OVS and Neutron on Kernels <3.3 (CentOS)", "label": "Enable OVS VLAN splinters soft trunks workaround"}, {"data": "hard", "description": "Configure OVS to use VLAN splinters workaround with hard trunk allocation. Offers similar effect as soft trunks workaround, but forces each trunk to be predefined. This may work better than soft trunks especially if you still see network problems using soft trunks", "label": "Enable OVS VLAN splinters hard trunks workaround"}, {"data": "kernel_lt", "description": "Install the Fedora 3.10 longterm kernel instead of the default 2.6.32 kernel. This should remove any need for VLAN Splinters workarounds as the 3.10 kernel has better support for OVS VLANs. This kernel may not work with all hardware platforms, use caution.", "label": "EXPERIMENTAL: Use Fedora longterm kernel"}], "type": "radio", "weight": 55, "value": "disabled", "label": "Open VSwitch VLAN Splinters feature (Neutron only)"}, "metadata": {"enabled": false, "weight": 50, "toggleable": true, "label": "VLAN Splinters"}}, "vcenter": {"use_vcenter": {"weight": 5, "type": "hidden", "description": "", "value": true, "label": ""}, "vc_user": {"description": "vCenter admin username", "weight": 30, "value": "", "label": "Username", "depends": [{"settings:common.libvirt_type.value": "vcenter"}], "type": "text"}, "host_ip": {"description": "IP Address of vCenter", "weight": 10, "value": "", "label": "vCenter IP", "depends": [{"settings:common.libvirt_type.value": "vcenter"}], "type": "text"}, "cluster": {"description": "vCenter cluster name", "weight": 40, "value": "", "label": "Cluster", "depends": [{"settings:common.libvirt_type.value": "vcenter"}], "type": "text"}, "vc_password": {"description": "vCenter admin password", "weight": 30, "value": "", "label": "Password", "depends": [{"settings:common.libvirt_type.value": "vcenter"}], "type": "password"}, "metadata": {"weight": 20, "label": "vCenter"}}}}	{"volumes_roles_mapping": {"compute": [{"id": "os", "allocate_size": "min"}, {"id": "vm", "allocate_size": "all"}], "mongo": [{"id": "os", "allocate_size": "min"}, {"id": "mongo", "allocate_size": "all"}], "controller": [{"id": "os", "allocate_size": "min"}, {"id": "image", "allocate_size": "all"}], "other": [{"id": "os", "allocate_size": "all"}], "ceph-osd": [{"id": "os", "allocate_size": "min"}, {"id": "cephjournal", "allocate_size": "min"}, {"id": "ceph", "allocate_size": "full-disk"}], "cinder": [{"id": "os", "allocate_size": "min"}, {"id": "cinder", "allocate_size": "all"}]}, "volumes": [{"min_size": {"generator": "calc_min_mongo_size"}, "type": "vg", "id": "mongo", "volumes": [{"mount": "/var/lib/mongo", "type": "lv", "name": "mongodb", "file_system": "ext4", "size": {"generator_args": ["mongo"], "generator": "calc_total_vg"}}], "label": "MongoDB"}, {"partition_guid": "4fbd7e29-9d25-41b8-afd0-062c0ceff05d", "name": "Ceph", "mount": "none", "label": "Ceph", "min_size": {"generator": "calc_min_ceph_size"}, "type": "partition", "id": "ceph", "file_system": "none"}, {"partition_guid": "45b0969e-9b03-4f30-b4c6-b4b80ceff106", "name": "Ceph Journal", "mount": "none", "label": "Ceph Journal", "min_size": {"generator": "calc_min_ceph_journal_size"}, "type": "partition", "id": "cephjournal", "file_system": "none"}, {"min_size": {"generator": "calc_min_os_size"}, "type": "vg", "id": "os", "volumes": [{"mount": "/", "type": "lv", "name": "root", "file_system": "ext4", "size": {"generator": "calc_total_root_vg"}}, {"mount": "swap", "type": "lv", "name": "swap", "file_system": "swap", "size": {"generator": "calc_swap_size"}}], "label": "Base System"}, {"min_size": {"generator": "calc_min_vm_size"}, "type": "vg", "id": "vm", "volumes": [{"mount": "/var/lib/nova", "type": "lv", "name": "nova", "file_system": "xfs", "size": {"generator_args": ["vm"], "generator": "calc_total_vg"}}], "label": "Virtual Storage"}, {"min_size": {"generator": "calc_min_glance_size"}, "type": "vg", "id": "image", "volumes": [{"mount": "/var/lib/glance", "type": "lv", "name": "glance", "file_system": "xfs", "size": {"generator_args": ["image"], "generator": "calc_total_vg"}}], "label": "Image Storage"}, {"min_size": {"generator": "calc_min_cinder_size"}, "type": "vg", "id": "cinder", "volumes": [], "label": "Cinder"}]}	{"ha_compact": {"description": "This configuration Deploys OpenStack ready for high availability (HA). Controller services are prepared for HA by setting up a base MySQL/Galera, RabbitMQ and HAProxy so that additional controllers can be deployed NOW, or scaled out LATER. 3 or more controllers are required for a true HA environment."}, "multinode": {"description": "In this configuration the OpenStack controller is deployed separately from the compute and cinder nodes. This mode assumes the presence of 1 controller node and 1 or more compute/cinder nodes. You can add more nodes to scale your cloud later."}}	{"cinder": {"name": "Storage - Cinder LVM", "description": "Cinder LVM provides block storage over iSCSI. Block storage can be used for database storage, expandable file systems, or providing a server with access to raw block level devices."}, "controller": {"conflicts": ["compute"], "name": "Controller", "description": "The controller initiates orchestration activities and provides an external API.  Other components like Glance (image storage), Keystone (identity management), Horizon (OpenStack dashboard) and Nova-Scheduler are installed on the controller as well."}, "compute": {"conflicts": ["controller", "mongo"], "name": "Compute", "description": "A compute node creates, manages and terminates virtual machine instances."}, "mongo": {"conflicts": ["compute", "ceph-osd"], "depends": [{"warning": "Ceilometer should be enabled", "condition": {"settings:additional_components.ceilometer.value": true}}], "name": "Telemetry - MongoDB", "description": "A feature-complete and recommended database for storage of metering data from OpenStack Telemetry (Ceilometer)."}, "ceph-osd": {"conflicts": ["mongo"], "name": "Storage - Ceph OSD", "description": "Ceph storage can be configured to provide storage for block volumes (Cinder), images (Glance) and ephemeral instance storage (Nova). It can also provide object storage through the S3 and Swift API (See settings to enable each)."}}
2	Icehouse on Ubuntu 12.04.4	2014.1.1-5.0.1	This option will install the OpenStack Icehouse packages using Ubuntu as a base operating system. With high availability features built in, you are getting a robust, enterprise-grade OpenStack deployment.	Ubuntu	available	{"nova_network": {"config": {"floating_ranges": [["172.16.0.128", "172.16.0.254"]], "net_manager": "FlatDHCPManager", "fixed_networks_vlan_start": 103, "fixed_networks_amount": 1, "fixed_network_size": 256, "fixed_networks_cidr": "10.0.0.0/16"}, "networks": [{"name": "public", "notation": "ip_ranges", "render_type": null, "map_priority": 1, "assign_vip": true, "use_gateway": true, "vlan_start": null, "render_addr_mask": "public", "cidr": "172.16.0.0/24", "configurable": true, "gateway": "172.16.0.1", "ip_range": ["172.16.0.2", "172.16.0.127"]}, {"name": "management", "notation": "cidr", "render_type": "cidr", "map_priority": 2, "assign_vip": true, "use_gateway": false, "vlan_start": 101, "render_addr_mask": "internal", "cidr": "192.168.0.0/24", "configurable": true}, {"name": "storage", "notation": "cidr", "render_type": "cidr", "map_priority": 2, "assign_vip": false, "use_gateway": false, "vlan_start": 102, "render_addr_mask": "storage", "cidr": "192.168.1.0/24", "configurable": true}, {"ext_net_data": ["fixed_networks_vlan_start", "fixed_networks_amount"], "name": "fixed", "notation": null, "render_type": null, "map_priority": 2, "assign_vip": false, "use_gateway": false, "vlan_start": null, "render_addr_mask": null, "configurable": false}]}, "neutron": {"config": {"parameters": {"metadata": {"metadata_proxy_shared_secret": ""}, "keystone": {"admin_user": null, "admin_password": ""}, "amqp": {"username": null, "passwd": "", "hosts": "hostname1:5672, hostname2:5672", "provider": "rabbitmq"}, "database": {"username": null, "passwd": "", "database": null, "port": "3306", "provider": "mysql"}}, "internal_cidr": "192.168.111.0/24", "internal_gateway": "192.168.111.1", "floating_ranges": [["172.16.0.130", "172.16.0.254"]], "base_mac": "fa:16:3e:00:00:00", "gre_id_range": [2, 65535], "vlan_range": [1000, 1030]}, "networks": [{"name": "public", "notation": "ip_ranges", "render_type": null, "map_priority": 1, "assign_vip": true, "floating_range_var": "floating_ranges", "use_gateway": true, "vlan_start": null, "render_addr_mask": "public", "cidr": "172.16.0.0/24", "configurable": true, "ip_range": ["172.16.0.2", "172.16.0.126"]}, {"name": "management", "notation": "cidr", "render_type": "cidr", "map_priority": 2, "assign_vip": true, "use_gateway": false, "vlan_start": 101, "render_addr_mask": "internal", "cidr": "192.168.0.0/24", "configurable": true}, {"name": "storage", "notation": "cidr", "render_type": "cidr", "map_priority": 2, "assign_vip": false, "use_gateway": false, "vlan_start": 102, "render_addr_mask": "storage", "cidr": "192.168.1.0/24", "configurable": true}, {"name": "private", "notation": null, "render_type": null, "map_priority": 2, "assign_vip": false, "use_gateway": false, "vlan_start": null, "render_addr_mask": null, "neutron_vlan_range": true, "configurable": false, "seg_type": "vlan"}]}}	{"generated": {"quantum_settings": {"metadata": {"metadata_proxy_shared_secret": {"generator": "password"}}, "keystone": {"admin_password": {"generator": "password"}}, "database": {"passwd": {"generator": "password"}}}, "base_syslog": {"syslog_port": {"generator": "identical", "generator_arg": "514"}, "syslog_server": {"generator": "ip", "generator_arg": "admin"}}, "ceilometer": {"db_password": {"generator": "password"}, "user_password": {"generator": "password"}, "metering_secret": {"generator": "password"}}, "murano": {"db_password": {"generator": "password"}, "user_password": {"generator": "password"}, "rabbit_password": {"generator": "password"}}, "nova": {"db_password": {"generator": "password"}, "user_password": {"generator": "password"}, "state_path": "/var/lib/nova"}, "heat": {"db_password": {"generator": "password"}, "user_password": {"generator": "password"}, "rabbit_password": {"generator": "password"}}, "keystone": {"db_password": {"generator": "password"}, "admin_token": {"generator": "password"}}, "rabbit": {"password": {"generator": "password"}}, "mysql": {"root_password": {"generator": "password"}}, "sahara": {"db_password": {"generator": "password"}, "user_password": {"generator": "password"}}, "cobbler": {"profile": {"generator": "identical", "generator_arg": "ubuntu_1204_x86_64"}}, "cinder": {"db_password": {"generator": "password"}, "user_password": {"generator": "password"}}, "swift": {"user_password": {"generator": "password"}}, "glance": {"db_password": {"generator": "password"}, "user_password": {"generator": "password"}}}, "editable": {"additional_components": {"murano": {"description": "If selected, Murano component will be installed", "weight": 20, "value": false, "label": "Install Murano", "depends": [{"cluster:net_provider": "neutron"}], "type": "checkbox"}, "ceilometer": {"value": false, "type": "checkbox", "description": "If selected, Ceilometer component will be installed", "weight": 40, "label": "Install Ceilometer"}, "sahara": {"value": false, "type": "checkbox", "description": "If selected, Sahara component will be installed", "weight": 10, "label": "Install Sahara"}, "heat": {"value": true, "type": "hidden", "description": "", "weight": 30, "label": ""}, "metadata": {"weight": 20, "label": "Additional Components"}}, "syslog": {"syslog_port": {"weight": 20, "type": "text", "description": "Remote syslog port", "value": "514", "label": "Port"}, "syslog_transport": {"type": "radio", "values": [{"data": "udp", "description": "", "label": "UDP"}, {"data": "tcp", "description": "", "label": "TCP"}], "weight": 30, "value": "tcp", "label": "Syslog transport protocol"}, "syslog_server": {"weight": 10, "type": "text", "description": "Remote syslog hostname", "value": "", "label": "Hostname"}, "metadata": {"weight": 50, "label": "Syslog"}}, "storage": {"volumes_ceph": {"description": "Configures Cinder to store volumes in Ceph RBD images.", "weight": 20, "value": false, "label": "Ceph RBD for volumes (Cinder)", "conflicts": [{"settings:common.libvirt_type.value": "vcenter"}, {"settings:storage.volumes_lvm.value": true}], "type": "checkbox"}, "objects_ceph": {"description": "Configures RadosGW front end for Ceph RBD. This exposes S3 and Swift API Interfaces. If enabled, this option will prevent Swift from installing.", "weight": 40, "value": false, "label": "Ceph RadosGW for objects (Swift API)", "depends": [{"settings:storage.images_ceph.value": true}], "conflicts": [{"settings:common.libvirt_type.value": "vcenter"}], "type": "checkbox"}, "ephemeral_ceph": {"description": "Configures Nova to store ephemeral volumes in RBD. This works best if Ceph is enabled for volumes and images, too. Enables live migration of all types of Ceph backed VMs (without this option, live migration will only work with VMs launched from Cinder volumes).", "weight": 35, "value": false, "label": "Ceph RBD for ephemeral volumes (Nova)", "conflicts": [{"settings:common.libvirt_type.value": "vcenter"}], "type": "checkbox"}, "volumes_lvm": {"description": "Requires at least one Storage - Cinder LVM node.", "weight": 10, "value": true, "label": "Cinder LVM over iSCSI for volumes", "conflicts": [{"settings:storage.volumes_ceph.value": true}], "type": "checkbox"}, "osd_pool_size": {"description": "Configures the default number of object replicas in Ceph. This number must be equal to or lower than the number of deployed 'Storage - Ceph OSD' nodes.", "weight": 70, "value": "2", "label": "Ceph object replication factor", "conflicts": [{"settings:common.libvirt_type.value": "vcenter"}], "type": "text"}, "images_ceph": {"description": "Configures Glance to use the Ceph RBD backend to store images. If enabled, this option will prevent Swift from installing.", "weight": 30, "value": false, "label": "Ceph RBD for images (Glance)", "conflicts": [{"settings:common.libvirt_type.value": "vcenter"}], "type": "checkbox"}, "metadata": {"weight": 60, "label": "Storage"}}, "access": {"user": {"regex": {"source": "^(?!services$)(?!nova$)(?!glance$)(?!keystone$)(?!neutron$)(?!cinder$)(?!swift$)(?!ceph$)(?![Gg]uest$).*", "error": "Invalid username"}, "description": "Username for Administrator", "weight": 10, "value": "admin", "label": "username", "type": "text"}, "password": {"weight": 20, "type": "password", "description": "Password for Administrator", "value": "admin", "label": "password"}, "email": {"weight": 40, "type": "text", "description": "Email address for Administrator", "value": "admin@example.org", "label": "email"}, "tenant": {"regex": {"source": "^(?!services$)(?!nova$)(?!glance$)(?!keystone$)(?!neutron$)(?!cinder$)(?!swift$)(?!ceph$)(?![Gg]uest$).*", "error": "Invalid tenant name"}, "description": "Tenant (project) name for Administrator", "weight": 30, "value": "admin", "label": "tenant", "type": "text"}, "metadata": {"weight": 10, "label": "Access"}}, "kernel_params": {"kernel": {"value": "console=ttyS0,9600 console=tty0 rootdelay=90 nomodeset", "type": "text", "description": "Default kernel parameters", "weight": 45, "label": "Initial parameters"}, "metadata": {"weight": 40, "label": "Kernel parameters"}}, "common": {"auto_assign_floating_ip": {"description": "If selected, OpenStack will automatically assign a floating IP to a new instance", "weight": 40, "value": false, "label": "Auto assign floating IP", "conflicts": [{"cluster:net_provider": "neutron"}], "type": "checkbox"}, "use_cow_images": {"weight": 50, "type": "checkbox", "description": "For most cases you will want qcow format. If it's disabled, raw image format will be used to run VMs. OpenStack with raw format currently does not support snapshotting.", "value": true, "label": "Use qcow format for images"}, "auth_key": {"weight": 70, "type": "text", "description": "Public key(s) to include in authorized_keys on deployed nodes", "value": "", "label": "Public Key"}, "compute_scheduler_driver": {"type": "radio", "values": [{"data": "nova.scheduler.filter_scheduler.FilterScheduler", "description": "Currently the most advanced OpenStack scheduler. See the OpenStack documentation for details.", "label": "Filter scheduler"}, {"data": "nova.scheduler.simple.SimpleScheduler", "description": "This is 'naive' scheduler which tries to find the least loaded host", "label": "Simple scheduler"}], "weight": 40, "value": "nova.scheduler.filter_scheduler.FilterScheduler", "label": "Scheduler driver"}, "libvirt_type": {"type": "radio", "values": [{"data": "kvm", "description": "Choose this type of hypervisor if you run OpenStack on hardware", "label": "KVM"}, {"data": "qemu", "description": "Choose this type of hypervisor if you run OpenStack on virtual hosts.", "label": "QEMU"}, {"conflicts": [{"cluster:net_provider": "neutron"}], "data": "vcenter", "description": "Choose this type of hypervisor if you run OpenStack in a vCenter environment.", "label": "vCenter"}], "weight": 30, "value": "qemu", "label": "Hypervisor type"}, "start_guests_on_host_boot": {"weight": 60, "type": "checkbox", "description": "Whether to (re-)start guests when the host reboots. If enabled, this option causes guests assigned to the host to be unconditionally restarted when nova-compute starts. If the guest is found to be stopped, it starts. If it is found to be running, it reboots.", "value": true, "label": "Start guests on host boot"}, "debug": {"weight": 20, "type": "checkbox", "description": "Debug logging mode provides more information, but requires more disk space.", "value": false, "label": "OpenStack debug logging"}, "nova_quota": {"weight": 25, "type": "checkbox", "description": "Quotas are used to limit CPU and memory usage for tenants. Enabling quotas will increase load on the Nova database.", "value": false, "label": "Nova quotas"}, "metadata": {"weight": 30, "label": "Common"}}, "vcenter": {"use_vcenter": {"weight": 5, "type": "hidden", "description": "", "value": true, "label": ""}, "vc_user": {"description": "vCenter admin username", "weight": 30, "value": "", "label": "Username", "depends": [{"settings:common.libvirt_type.value": "vcenter"}], "type": "text"}, "host_ip": {"description": "IP Address of vCenter", "weight": 10, "value": "", "label": "vCenter IP", "depends": [{"settings:common.libvirt_type.value": "vcenter"}], "type": "text"}, "cluster": {"description": "vCenter cluster name", "weight": 40, "value": "", "label": "Cluster", "depends": [{"settings:common.libvirt_type.value": "vcenter"}], "type": "text"}, "vc_password": {"description": "vCenter admin password", "weight": 30, "value": "", "label": "Password", "depends": [{"settings:common.libvirt_type.value": "vcenter"}], "type": "password"}, "metadata": {"weight": 20, "label": "vCenter"}}}}	{"volumes_roles_mapping": {"compute": [{"id": "os", "allocate_size": "min"}, {"id": "vm", "allocate_size": "all"}], "mongo": [{"id": "os", "allocate_size": "min"}, {"id": "mongo", "allocate_size": "all"}], "controller": [{"id": "os", "allocate_size": "min"}, {"id": "image", "allocate_size": "all"}], "other": [{"id": "os", "allocate_size": "all"}], "ceph-osd": [{"id": "os", "allocate_size": "min"}, {"id": "cephjournal", "allocate_size": "min"}, {"id": "ceph", "allocate_size": "full-disk"}], "cinder": [{"id": "os", "allocate_size": "min"}, {"id": "cinder", "allocate_size": "all"}]}, "volumes": [{"min_size": {"generator": "calc_min_mongo_size"}, "type": "vg", "id": "mongo", "volumes": [{"mount": "/var/lib/mongo", "type": "lv", "name": "mongodb", "file_system": "ext4", "size": {"generator_args": ["mongo"], "generator": "calc_total_vg"}}], "label": "MongoDB"}, {"partition_guid": "4fbd7e29-9d25-41b8-afd0-062c0ceff05d", "name": "Ceph", "mount": "none", "label": "Ceph", "min_size": {"generator": "calc_min_ceph_size"}, "type": "partition", "id": "ceph", "file_system": "none"}, {"partition_guid": "45b0969e-9b03-4f30-b4c6-b4b80ceff106", "name": "Ceph Journal", "mount": "none", "label": "Ceph Journal", "min_size": {"generator": "calc_min_ceph_journal_size"}, "type": "partition", "id": "cephjournal", "file_system": "none"}, {"min_size": {"generator": "calc_min_os_size"}, "type": "vg", "id": "os", "volumes": [{"mount": "/", "type": "lv", "name": "root", "file_system": "ext4", "size": {"generator": "calc_total_root_vg"}}, {"mount": "swap", "type": "lv", "name": "swap", "file_system": "swap", "size": {"generator": "calc_swap_size"}}], "label": "Base System"}, {"min_size": {"generator": "calc_min_vm_size"}, "type": "vg", "id": "vm", "volumes": [{"mount": "/var/lib/nova", "type": "lv", "name": "nova", "file_system": "xfs", "size": {"generator_args": ["vm"], "generator": "calc_total_vg"}}], "label": "Virtual Storage"}, {"min_size": {"generator": "calc_min_glance_size"}, "type": "vg", "id": "image", "volumes": [{"mount": "/var/lib/glance", "type": "lv", "name": "glance", "file_system": "xfs", "size": {"generator_args": ["image"], "generator": "calc_total_vg"}}], "label": "Image Storage"}, {"min_size": {"generator": "calc_min_cinder_size"}, "type": "vg", "id": "cinder", "volumes": [], "label": "Cinder"}]}	{"ha_compact": {"description": "This configuration Deploys OpenStack ready for high availability (HA). Controller services are prepared for HA by setting up a base MySQL/Galera, RabbitMQ and HAProxy so that additional controllers can be deployed NOW, or scaled out LATER. 3 or more controllers are required for a true HA environment."}, "multinode": {"description": "In this configuration the OpenStack controller is deployed separately from the compute and cinder nodes. This mode assumes the presence of 1 controller node and 1 or more compute/cinder nodes. You can add more nodes to scale your cloud later."}}	{"cinder": {"name": "Storage - Cinder LVM", "description": "Cinder LVM provides block storage over iSCSI. Block storage can be used for database storage, expandable file systems, or providing a server with access to raw block level devices."}, "controller": {"conflicts": ["compute"], "name": "Controller", "description": "The controller initiates orchestration activities and provides an external API.  Other components like Glance (image storage), Keystone (identity management), Horizon (OpenStack dashboard) and Nova-Scheduler are installed on the controller as well."}, "compute": {"conflicts": ["controller", "mongo"], "name": "Compute", "description": "A compute node creates, manages and terminates virtual machine instances."}, "mongo": {"conflicts": ["compute", "ceph-osd"], "depends": [{"warning": "Ceilometer should be enabled", "condition": {"settings:additional_components.ceilometer.value": true}}], "name": "Telemetry - MongoDB", "description": "A feature-complete and recommended database for storage of metering data from OpenStack Telemetry (Ceilometer)."}, "ceph-osd": {"conflicts": ["mongo"], "name": "Storage - Ceph OSD", "description": "Ceph storage can be configured to provide storage for block volumes (Cinder), images (Glance) and ephemeral instance storage (Nova). It can also provide object storage through the S3 and Swift API (See settings to enable each)."}}
\.


--
-- Name: releases_id_seq; Type: SEQUENCE SET; Schema: public; Owner: nailgun
--

SELECT pg_catalog.setval('releases_id_seq', 2, true);


--
-- Data for Name: roles; Type: TABLE DATA; Schema: public; Owner: nailgun
--

COPY roles (id, release_id, name) FROM stdin;
1	1	controller
2	1	compute
3	1	cinder
4	1	ceph-osd
5	1	mongo
6	2	controller
7	2	compute
8	2	cinder
9	2	ceph-osd
10	2	mongo
\.


--
-- Name: roles_id_seq; Type: SEQUENCE SET; Schema: public; Owner: nailgun
--

SELECT pg_catalog.setval('roles_id_seq', 10, true);


--
-- Data for Name: tasks; Type: TABLE DATA; Schema: public; Owner: nailgun
--

COPY tasks (id, cluster_id, uuid, name, message, status, progress, cache, result, parent_id, weight) FROM stdin;
1	\N	3a206770-1cbf-4c70-8b65-12e1ea3606d7	dump	\N	running	0	{"args": {"task_uuid": "3a206770-1cbf-4c70-8b65-12e1ea3606d7", "settings": {"timestamp": true, "lastdump": "/var/www/nailgun/dump/last", "target": "/var/www/nailgun/dump/fuel-snapshot", "dump": {"master": {"objects": [{"path": "/etc/nailgun", "type": "dir"}, {"path": "/etc/astute", "type": "dir"}, {"path": "/etc/fuel", "type": "dir"}, {"command": "df -h", "to_file": "df.txt", "type": "command"}, {"command": "mount", "to_file": "mount.txt", "type": "command"}, {"command": "iptables -t nat -S", "to_file": "iptables_nat.txt", "type": "command"}, {"command": "iptables -t filter -S", "to_file": "iptables_filter.txt", "type": "command"}, {"command": "dmidecode", "to_file": "dmidecode.txt", "type": "command"}, {"command": "uptime", "to_file": "uptime.txt", "type": "command"}, {"command": "ps auxwwf", "to_file": "ps.txt", "type": "command"}, {"command": "pvdisplay", "to_file": "lvm_pvdisplay.txt", "type": "command"}, {"command": "docker images", "to_file": "docker_images.txt", "type": "command"}, {"command": "docker ps", "to_file": "docker_ps.txt", "type": "command"}, {"command": "vgdisplay", "to_file": "lvm_vgdisplay.txt", "type": "command"}, {"command": "lvdisplay", "to_file": "lvm_lvdisplay.txt", "type": "command"}, {"command": "ip a", "to_file": "ip_a.txt", "type": "command"}, {"command": "ip r", "to_file": "ip_r.txt", "type": "command"}, {"command": "netstat -anp", "to_file": "netstat.txt", "type": "command"}, {"command": "brctl show", "to_file": "brctl_show.txt", "type": "command"}, {"path": "/etc/sysconfig/network-scripts", "type": "dir"}, {"path": "/etc/dnsmasq.conf", "type": "file"}, {"path": "/root/*.log", "type": "file"}, {"path": "/etc/cobbler*", "type": "file"}, {"path": "/var/log/fuelmenu.log", "type": "file"}, {"path": "/var/log/docker-logs", "type": "dir"}, {"path": "/var/log/docker-*.log", "type": "file"}, {"path": "/var/log/puppet/bootstrap_admin_node.log", "type": "file"}, {"path": "/var/log/fuel_upgrade.log", "type": "file"}], "hosts": [{"ssh-key": "/root/.ssh/id_rsa", "address": "10.108.0.2"}]}, "local": {"objects": [{"path": "/var/log/nailgun", "type": "dir"}, {"path": "/var/log/astute", "type": "dir"}, {"path": "/var/log/cobbler", "type": "dir"}, {"path": "/var/log/puppet", "type": "dir"}, {"path": "/var/log/remote", "type": "subs", "subs": {}}, {"path": "/var/log/ostf.log", "type": "file"}, {"path": "/var/log/ostf-stdout.log", "type": "file"}, {"path": "/var/log/docker", "type": "file"}, {"username": "nailgun", "dbhost": "10.108.0.2", "password": "nailgun", "type": "postgres", "dbname": "nailgun"}, {"to_file": "cobbler.txt", "type": "xmlrpc", "methods": ["get_distros", "get_profiles", "get_systems"], "server": "http://10.108.0.2:80/cobbler_api"}], "hosts": [{"ssh-key": "/root/.ssh/id_rsa", "address": "localhost"}]}, "slave": {"objects": [{"path": "/etc/astute.yaml", "type": "file"}, {"path": "/root/ceph*", "type": "file"}, {"path": "/root/anaconda*", "type": "file"}, {"path": "/root/*.log", "type": "file"}, {"path": "/root/*.ks", "type": "file"}, {"path": "/etc/ceph*", "type": "file"}, {"path": "/etc/keystone*", "type": "file"}, {"path": "/etc/nova*", "type": "file"}, {"path": "/etc/neutron*", "type": "file"}, {"path": "/etc/horizon*", "type": "file"}, {"path": "/etc/cinder*", "type": "file"}, {"path": "/etc/glance*", "type": "file"}, {"path": "/etc/swift*", "type": "file"}, {"path": "/var/log/ceph", "type": "file"}, {"path": "/etc/resolv.conf", "type": "file"}, {"command": "df -h", "to_file": "df.txt", "type": "command"}, {"command": "mount", "to_file": "mount.txt", "type": "command"}, {"command": "iptables -t nat -S", "to_file": "iptables_nat.txt", "type": "command"}, {"command": "iptables -t filter -S", "to_file": "iptables_filter.txt", "type": "command"}, {"command": "dmidecode", "to_file": "dmidecode.txt", "type": "command"}, {"command": "uptime", "to_file": "uptime.txt", "type": "command"}, {"command": "ps auxwwf", "to_file": "ps.txt", "type": "command"}, {"command": "pvdisplay", "to_file": "lvm_pvdisplay.txt", "type": "command"}, {"command": "vgdisplay", "to_file": "lvm_vgdisplay.txt", "type": "command"}, {"command": "lvdisplay", "to_file": "lvm_lvdisplay.txt", "type": "command"}, {"command": "ip a", "to_file": "ip_a.txt", "type": "command"}, {"command": "ip r", "to_file": "ip_r.txt", "type": "command"}, {"command": "netstat -anp", "to_file": "netstat.txt", "type": "command"}, {"command": "brctl show", "to_file": "brctl_show.txt", "type": "command"}, {"path": "/etc/sysconfig/network-scripts", "type": "dir"}, {"path": "/etc/network/interfaces.d", "type": "dir"}, {"path": "/etc/network/interfaces", "type": "file"}, {"path": "/root/post-partition.log", "type": "file"}, {"command": "blkid -o list", "to_file": "blkid_o_list.txt", "type": "command"}], "hosts": []}}}}, "respond_to": "dump_environment_resp", "method": "dump_environment", "api_version": "1.0"}	{}	\N	1
\.


--
-- Name: tasks_id_seq; Type: SEQUENCE SET; Schema: public; Owner: nailgun
--

SELECT pg_catalog.setval('tasks_id_seq', 1, true);


--
-- Name: attributes_pkey; Type: CONSTRAINT; Schema: public; Owner: nailgun; Tablespace: 
--

ALTER TABLE ONLY attributes
    ADD CONSTRAINT attributes_pkey PRIMARY KEY (id);


--
-- Name: capacity_log_pkey; Type: CONSTRAINT; Schema: public; Owner: nailgun; Tablespace: 
--

ALTER TABLE ONLY capacity_log
    ADD CONSTRAINT capacity_log_pkey PRIMARY KEY (id);


--
-- Name: cluster_changes_pkey; Type: CONSTRAINT; Schema: public; Owner: nailgun; Tablespace: 
--

ALTER TABLE ONLY cluster_changes
    ADD CONSTRAINT cluster_changes_pkey PRIMARY KEY (id);


--
-- Name: clusters_name_key; Type: CONSTRAINT; Schema: public; Owner: nailgun; Tablespace: 
--

ALTER TABLE ONLY clusters
    ADD CONSTRAINT clusters_name_key UNIQUE (name);


--
-- Name: clusters_pkey; Type: CONSTRAINT; Schema: public; Owner: nailgun; Tablespace: 
--

ALTER TABLE ONLY clusters
    ADD CONSTRAINT clusters_pkey PRIMARY KEY (id);


--
-- Name: ip_addr_ranges_pkey; Type: CONSTRAINT; Schema: public; Owner: nailgun; Tablespace: 
--

ALTER TABLE ONLY ip_addr_ranges
    ADD CONSTRAINT ip_addr_ranges_pkey PRIMARY KEY (id);


--
-- Name: ip_addrs_pkey; Type: CONSTRAINT; Schema: public; Owner: nailgun; Tablespace: 
--

ALTER TABLE ONLY ip_addrs
    ADD CONSTRAINT ip_addrs_pkey PRIMARY KEY (id);


--
-- Name: net_bond_assignments_pkey; Type: CONSTRAINT; Schema: public; Owner: nailgun; Tablespace: 
--

ALTER TABLE ONLY net_bond_assignments
    ADD CONSTRAINT net_bond_assignments_pkey PRIMARY KEY (id);


--
-- Name: net_nic_assignments_pkey; Type: CONSTRAINT; Schema: public; Owner: nailgun; Tablespace: 
--

ALTER TABLE ONLY net_nic_assignments
    ADD CONSTRAINT net_nic_assignments_pkey PRIMARY KEY (id);


--
-- Name: network_groups_pkey; Type: CONSTRAINT; Schema: public; Owner: nailgun; Tablespace: 
--

ALTER TABLE ONLY network_groups
    ADD CONSTRAINT network_groups_pkey PRIMARY KEY (id);


--
-- Name: networking_configs_pkey; Type: CONSTRAINT; Schema: public; Owner: nailgun; Tablespace: 
--

ALTER TABLE ONLY networking_configs
    ADD CONSTRAINT networking_configs_pkey PRIMARY KEY (id);


--
-- Name: neutron_config_pkey; Type: CONSTRAINT; Schema: public; Owner: nailgun; Tablespace: 
--

ALTER TABLE ONLY neutron_config
    ADD CONSTRAINT neutron_config_pkey PRIMARY KEY (id);


--
-- Name: node_attributes_pkey; Type: CONSTRAINT; Schema: public; Owner: nailgun; Tablespace: 
--

ALTER TABLE ONLY node_attributes
    ADD CONSTRAINT node_attributes_pkey PRIMARY KEY (id);


--
-- Name: node_bond_interfaces_pkey; Type: CONSTRAINT; Schema: public; Owner: nailgun; Tablespace: 
--

ALTER TABLE ONLY node_bond_interfaces
    ADD CONSTRAINT node_bond_interfaces_pkey PRIMARY KEY (id);


--
-- Name: node_nic_interfaces_pkey; Type: CONSTRAINT; Schema: public; Owner: nailgun; Tablespace: 
--

ALTER TABLE ONLY node_nic_interfaces
    ADD CONSTRAINT node_nic_interfaces_pkey PRIMARY KEY (id);


--
-- Name: node_roles_pkey; Type: CONSTRAINT; Schema: public; Owner: nailgun; Tablespace: 
--

ALTER TABLE ONLY node_roles
    ADD CONSTRAINT node_roles_pkey PRIMARY KEY (id);


--
-- Name: nodes_mac_key; Type: CONSTRAINT; Schema: public; Owner: nailgun; Tablespace: 
--

ALTER TABLE ONLY nodes
    ADD CONSTRAINT nodes_mac_key UNIQUE (mac);


--
-- Name: nodes_pkey; Type: CONSTRAINT; Schema: public; Owner: nailgun; Tablespace: 
--

ALTER TABLE ONLY nodes
    ADD CONSTRAINT nodes_pkey PRIMARY KEY (id);


--
-- Name: nodes_uuid_key; Type: CONSTRAINT; Schema: public; Owner: nailgun; Tablespace: 
--

ALTER TABLE ONLY nodes
    ADD CONSTRAINT nodes_uuid_key UNIQUE (uuid);


--
-- Name: notifications_pkey; Type: CONSTRAINT; Schema: public; Owner: nailgun; Tablespace: 
--

ALTER TABLE ONLY notifications
    ADD CONSTRAINT notifications_pkey PRIMARY KEY (id);


--
-- Name: nova_network_config_pkey; Type: CONSTRAINT; Schema: public; Owner: nailgun; Tablespace: 
--

ALTER TABLE ONLY nova_network_config
    ADD CONSTRAINT nova_network_config_pkey PRIMARY KEY (id);


--
-- Name: pending_node_roles_pkey; Type: CONSTRAINT; Schema: public; Owner: nailgun; Tablespace: 
--

ALTER TABLE ONLY pending_node_roles
    ADD CONSTRAINT pending_node_roles_pkey PRIMARY KEY (id);


--
-- Name: red_hat_accounts_pkey; Type: CONSTRAINT; Schema: public; Owner: nailgun; Tablespace: 
--

ALTER TABLE ONLY red_hat_accounts
    ADD CONSTRAINT red_hat_accounts_pkey PRIMARY KEY (id);


--
-- Name: release_orchestrator_data_pkey; Type: CONSTRAINT; Schema: public; Owner: nailgun; Tablespace: 
--

ALTER TABLE ONLY release_orchestrator_data
    ADD CONSTRAINT release_orchestrator_data_pkey PRIMARY KEY (id);


--
-- Name: releases_name_version_key; Type: CONSTRAINT; Schema: public; Owner: nailgun; Tablespace: 
--

ALTER TABLE ONLY releases
    ADD CONSTRAINT releases_name_version_key UNIQUE (name, version);


--
-- Name: releases_pkey; Type: CONSTRAINT; Schema: public; Owner: nailgun; Tablespace: 
--

ALTER TABLE ONLY releases
    ADD CONSTRAINT releases_pkey PRIMARY KEY (id);


--
-- Name: roles_name_release_id_key; Type: CONSTRAINT; Schema: public; Owner: nailgun; Tablespace: 
--

ALTER TABLE ONLY roles
    ADD CONSTRAINT roles_name_release_id_key UNIQUE (name, release_id);


--
-- Name: roles_pkey; Type: CONSTRAINT; Schema: public; Owner: nailgun; Tablespace: 
--

ALTER TABLE ONLY roles
    ADD CONSTRAINT roles_pkey PRIMARY KEY (id);


--
-- Name: tasks_pkey; Type: CONSTRAINT; Schema: public; Owner: nailgun; Tablespace: 
--

ALTER TABLE ONLY tasks
    ADD CONSTRAINT tasks_pkey PRIMARY KEY (id);


--
-- Name: attributes_cluster_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nailgun
--

ALTER TABLE ONLY attributes
    ADD CONSTRAINT attributes_cluster_id_fkey FOREIGN KEY (cluster_id) REFERENCES clusters(id);


--
-- Name: cluster_changes_cluster_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nailgun
--

ALTER TABLE ONLY cluster_changes
    ADD CONSTRAINT cluster_changes_cluster_id_fkey FOREIGN KEY (cluster_id) REFERENCES clusters(id);


--
-- Name: cluster_changes_node_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nailgun
--

ALTER TABLE ONLY cluster_changes
    ADD CONSTRAINT cluster_changes_node_id_fkey FOREIGN KEY (node_id) REFERENCES nodes(id) ON DELETE CASCADE;


--
-- Name: clusters_release_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nailgun
--

ALTER TABLE ONLY clusters
    ADD CONSTRAINT clusters_release_id_fkey FOREIGN KEY (release_id) REFERENCES releases(id);


--
-- Name: ip_addr_ranges_network_group_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nailgun
--

ALTER TABLE ONLY ip_addr_ranges
    ADD CONSTRAINT ip_addr_ranges_network_group_id_fkey FOREIGN KEY (network_group_id) REFERENCES network_groups(id);


--
-- Name: ip_addrs_network_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nailgun
--

ALTER TABLE ONLY ip_addrs
    ADD CONSTRAINT ip_addrs_network_fkey FOREIGN KEY (network) REFERENCES network_groups(id) ON DELETE CASCADE;


--
-- Name: ip_addrs_node_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nailgun
--

ALTER TABLE ONLY ip_addrs
    ADD CONSTRAINT ip_addrs_node_fkey FOREIGN KEY (node) REFERENCES nodes(id) ON DELETE CASCADE;


--
-- Name: net_bond_assignments_bond_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nailgun
--

ALTER TABLE ONLY net_bond_assignments
    ADD CONSTRAINT net_bond_assignments_bond_id_fkey FOREIGN KEY (bond_id) REFERENCES node_bond_interfaces(id) ON DELETE CASCADE;


--
-- Name: net_bond_assignments_network_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nailgun
--

ALTER TABLE ONLY net_bond_assignments
    ADD CONSTRAINT net_bond_assignments_network_id_fkey FOREIGN KEY (network_id) REFERENCES network_groups(id) ON DELETE CASCADE;


--
-- Name: net_nic_assignments_interface_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nailgun
--

ALTER TABLE ONLY net_nic_assignments
    ADD CONSTRAINT net_nic_assignments_interface_id_fkey FOREIGN KEY (interface_id) REFERENCES node_nic_interfaces(id) ON DELETE CASCADE;


--
-- Name: net_nic_assignments_network_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nailgun
--

ALTER TABLE ONLY net_nic_assignments
    ADD CONSTRAINT net_nic_assignments_network_id_fkey FOREIGN KEY (network_id) REFERENCES network_groups(id) ON DELETE CASCADE;


--
-- Name: network_groups_cluster_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nailgun
--

ALTER TABLE ONLY network_groups
    ADD CONSTRAINT network_groups_cluster_id_fkey FOREIGN KEY (cluster_id) REFERENCES clusters(id);


--
-- Name: network_groups_release_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nailgun
--

ALTER TABLE ONLY network_groups
    ADD CONSTRAINT network_groups_release_fkey FOREIGN KEY (release) REFERENCES releases(id);


--
-- Name: networking_configs_cluster_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nailgun
--

ALTER TABLE ONLY networking_configs
    ADD CONSTRAINT networking_configs_cluster_id_fkey FOREIGN KEY (cluster_id) REFERENCES clusters(id) ON DELETE CASCADE;


--
-- Name: neutron_config_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nailgun
--

ALTER TABLE ONLY neutron_config
    ADD CONSTRAINT neutron_config_id_fkey FOREIGN KEY (id) REFERENCES networking_configs(id);


--
-- Name: node_attributes_node_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nailgun
--

ALTER TABLE ONLY node_attributes
    ADD CONSTRAINT node_attributes_node_id_fkey FOREIGN KEY (node_id) REFERENCES nodes(id);


--
-- Name: node_bond_interfaces_node_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nailgun
--

ALTER TABLE ONLY node_bond_interfaces
    ADD CONSTRAINT node_bond_interfaces_node_id_fkey FOREIGN KEY (node_id) REFERENCES nodes(id) ON DELETE CASCADE;


--
-- Name: node_nic_interfaces_node_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nailgun
--

ALTER TABLE ONLY node_nic_interfaces
    ADD CONSTRAINT node_nic_interfaces_node_id_fkey FOREIGN KEY (node_id) REFERENCES nodes(id) ON DELETE CASCADE;


--
-- Name: node_nic_interfaces_parent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nailgun
--

ALTER TABLE ONLY node_nic_interfaces
    ADD CONSTRAINT node_nic_interfaces_parent_id_fkey FOREIGN KEY (parent_id) REFERENCES node_bond_interfaces(id);


--
-- Name: node_roles_node_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nailgun
--

ALTER TABLE ONLY node_roles
    ADD CONSTRAINT node_roles_node_fkey FOREIGN KEY (node) REFERENCES nodes(id);


--
-- Name: node_roles_role_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nailgun
--

ALTER TABLE ONLY node_roles
    ADD CONSTRAINT node_roles_role_fkey FOREIGN KEY (role) REFERENCES roles(id) ON DELETE CASCADE;


--
-- Name: nodes_cluster_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nailgun
--

ALTER TABLE ONLY nodes
    ADD CONSTRAINT nodes_cluster_id_fkey FOREIGN KEY (cluster_id) REFERENCES clusters(id);


--
-- Name: notifications_cluster_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nailgun
--

ALTER TABLE ONLY notifications
    ADD CONSTRAINT notifications_cluster_id_fkey FOREIGN KEY (cluster_id) REFERENCES clusters(id) ON DELETE SET NULL;


--
-- Name: notifications_node_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nailgun
--

ALTER TABLE ONLY notifications
    ADD CONSTRAINT notifications_node_id_fkey FOREIGN KEY (node_id) REFERENCES nodes(id) ON DELETE SET NULL;


--
-- Name: notifications_task_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nailgun
--

ALTER TABLE ONLY notifications
    ADD CONSTRAINT notifications_task_id_fkey FOREIGN KEY (task_id) REFERENCES tasks(id) ON DELETE SET NULL;


--
-- Name: nova_network_config_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nailgun
--

ALTER TABLE ONLY nova_network_config
    ADD CONSTRAINT nova_network_config_id_fkey FOREIGN KEY (id) REFERENCES networking_configs(id);


--
-- Name: pending_node_roles_node_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nailgun
--

ALTER TABLE ONLY pending_node_roles
    ADD CONSTRAINT pending_node_roles_node_fkey FOREIGN KEY (node) REFERENCES nodes(id);


--
-- Name: pending_node_roles_role_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nailgun
--

ALTER TABLE ONLY pending_node_roles
    ADD CONSTRAINT pending_node_roles_role_fkey FOREIGN KEY (role) REFERENCES roles(id) ON DELETE CASCADE;


--
-- Name: release_orchestrator_data_release_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nailgun
--

ALTER TABLE ONLY release_orchestrator_data
    ADD CONSTRAINT release_orchestrator_data_release_id_fkey FOREIGN KEY (release_id) REFERENCES releases(id);


--
-- Name: roles_release_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nailgun
--

ALTER TABLE ONLY roles
    ADD CONSTRAINT roles_release_id_fkey FOREIGN KEY (release_id) REFERENCES releases(id) ON DELETE CASCADE;


--
-- Name: tasks_cluster_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nailgun
--

ALTER TABLE ONLY tasks
    ADD CONSTRAINT tasks_cluster_id_fkey FOREIGN KEY (cluster_id) REFERENCES clusters(id);


--
-- Name: tasks_parent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: nailgun
--

ALTER TABLE ONLY tasks
    ADD CONSTRAINT tasks_parent_id_fkey FOREIGN KEY (parent_id) REFERENCES tasks(id);


--
-- Name: public; Type: ACL; Schema: -; Owner: postgres
--

REVOKE ALL ON SCHEMA public FROM PUBLIC;
REVOKE ALL ON SCHEMA public FROM postgres;
GRANT ALL ON SCHEMA public TO postgres;
GRANT ALL ON SCHEMA public TO PUBLIC;


--
-- PostgreSQL database dump complete
--

